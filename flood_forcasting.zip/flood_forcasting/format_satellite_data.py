#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created Summer 2018

Loads .nc satellite data (available at http://www.earth2observe.eu/)
downsamples along time/lat/long axis and saves as three numpy arrays

Loads inflow/outflow data of nangbeto reservoire. Access to this thanks to Pablo Saurez of red cross

Makes object where each row is the flow + satellite data for last 50 days
splits X (model inputs) and Y (model outputs) into training and testing data

Saves as object that CNN_flow_prediction.py uses to train a neural net to predict flow 10 days out.
@author: andrew.d.cutler@gmail.com
"""

import numpy as np
import csv, re, os, pickle
from netCDF4 import Dataset
from skimage.measure import block_reduce

def save_obj(obj, name ):
    with open('data/'+ name + '.pkl', 'wb') as f:
        pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)
        
def load_obj(name ):
    with open('data/' + name + '.pkl', 'rb') as f:
        return pickle.load(f)
        
def load_flows(filename = 'hydro.csv'):
    date = []
    inflow = []
    outflow = []
    with open("data/"+ filename) as csvfile:
        spamreader = csv.reader(csvfile, delimiter=",")
        for row in spamreader:
            if RepresentsInt(row[0]): 
                date += [row[1] + '/' + row[2] + '/' + row[0]]
                inflow += [re.sub('[^0-9]','',row[3])]
                outflow += [re.sub('[^0-9]','',row[4])]
        csvfile.close()
        for i in range(len(inflow)):
            if inflow[i] =='': inflow[i] = '-1'
            if outflow[i] == '': outflow[i] = '-1'
    return (date, np.array(inflow,dtype = int), np.array(outflow, dtype = int))

def RepresentsInt(s):
    try: 
        int(s)
        return True
    except ValueError:
        return False

#note, many comments were made 2 years after writing code.
#code has not been updated, if there is a discrpency on the details trust the paper over this


#data available from: http://www.earth2observe.eu/
#unzipped it is 31 .nc grids (1.9gb each)
#define their directory and empty arrays to store radiation, pressure and temperature satellite data
DIR = '../ForcingDataHydroModel-20180709T143515Z-001/ForcingDataHydroModel/nc_grids/'
nc_f = DIR+'201012260000_grid_Historic.nc'
nc_fid = Dataset(nc_f, 'r')
P = []
PET = []
TEMP = []

#for each .nc file in /data
#load the satellite grids (resolution: 28km x 28km x 3hrs)
#downsample by 8 along spatial and temporal axes
print("Loading .nc files")
for fname in sorted(os.listdir(DIR)):
    print(fname)
    data = Dataset(DIR+fname, 'r')
    p = data['P']
    p = p[:]
    p = np.ma.filled(p, fill_value = 0)
    p = block_reduce(p, block_size = (8,8,8), func = np.max)
    P += [p]
    
    pet = data['PET']
    pet = pet[:]
    pet = np.ma.filled(pet,fill_value = 0)
    pet = block_reduce(pet, block_size = (8,8,8), func = np.max)
    PET += [pet]
    
    t = data['TEMP']
    t = t[:]
    t = np.ma.filled(t,fill_value = 0)
    t = block_reduce(t,block_size = (8,8,8), func = np.max)
    TEMP += [t]
   
for y,p in enumerate(P):
    print(y)
    if (y-1)%4 !=0: 
        p = p[:-1] #remove last day from leap years (so data can be stored as a matrix) shape: (time,lat,long)
    if y == 0:
        a = p[-173:] # we only have inflow/outflow data for the last 173 days of 1987 (year 0)
    else: a = np.vstack((a,p))
    
for y,p in enumerate(PET):
    if (y-1)%4 !=0:
        p = p[:-1] 
    if y == 0:
        b = p[-173:] 
    else: b = np.vstack((b,p))
    
for y,p in enumerate(TEMP):
    if (y-1)%4 !=0: 
        p = p[:-1]
    if y == 0:
        c = p[-173:]
    else: c = np.vstack((c,p))
    
# save_obj((a,b,c), 'arrays_P_PET_TEMP')

#flow and satellite data
(date, inflow, outflow) = load_flows('flow_from_1987.csv')
(P,E,T) = load_obj('arrays_P_PET_TEMP')

#Construct y from future flows
Qin = []  #flow into reservoir
Qout = [] #flow released from dam
outflow[outflow>2000] = 59 #max entry is 5998, which is probably an error
for i in range(10):
    Qin += [inflow[i:].tolist() + [0]*i]
    Qout += [outflow[i:].tolist() + [0]*i]
#Q_diff = np.hstack((np.zeros((1,), dtype = int), inflow[1:] - inflow[:-1])).tolist()
y = np.array(Qin+Qout).T #removed Q_diff

#make data a series for each day
#Q_pand will be inflow and outflow data. shape = (n-k, k*2) = (11081,100)
#P,E,T will be (n-k,k, lat, lon) = (11081,50,45,19)
Qs = np.vstack((inflow,outflow)).T
k = 50 
Q_pand = []
for i in range(k,len(Qs)):
    if i%365 == 0:
        print(int(i/365) + 1987)
    temp = []
    temp += inflow[i-k:i].tolist()
    temp += outflow[i-k:i].tolist()
    Q_pand += [temp]
    if i ==k: #on first iteration make P,E,T expanded objects
        Pp = np.expand_dims(P[i-k:i,:,:], axis = 0)
        Ep = np.expand_dims(E[i-k:i,:,:], axis = 0)
        Tp = np.expand_dims(T[i-k:i,:,:], axis = 0)
    else: #on subsequent iterations concatenate with previous day
        Pp = np.vstack((Pp, np.expand_dims(P[i-k:i,:,:], axis = 0)))
        Ep = np.vstack((Ep, np.expand_dims(E[i-k:i,:,:], axis = 0)))
        Tp = np.vstack((Tp, np.expand_dims(T[i-k:i,:,:], axis = 0)))
Q_pand = np.array(Q_pand)

#split into train and test (starting at Jan 1, 2016)
#N = int(len(Q_pand)-365*3) #for last three years
N = np.argwhere(np.array(date, dtype = str) == '1/1/2016')[0][0]
X_train = [x[:N] for x in [Q_pand, Pp, Ep, Tp]]
X_test = [x[N:] for x in [Q_pand, Pp, Ep, Tp]]
y_train = y[k:N+k]
y_test = y[N+k:]

# save_obj((X_train,X_test, y_train, y_test), 'XY_traintest_50')
