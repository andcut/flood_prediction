#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created Summer 2018

Fits an auto-regressive random forest to time series inflow/outflow of the nangbeto reservoir
@author: andrew.d.cutler@gmail.com
"""

import numpy as np
import csv
import re

from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, GradientBoostingRegressor
from sklearn.metrics import explained_variance_score as ev
from sklearn.metrics import mean_squared_error as mse
# from sklearn.linear_model import RidgeCV
# from sklearn.externals import joblib

# from tpot import TPOTRegressor
# from pandas import Series, date_range, DataFrame
from new_metrics import NS, KGE

def RepresentsInt(s):
    try: 
        int(s)
        return True
    except ValueError:
        return False

def load_flows(filename = 'hydro.csv'):
    date = []
    inflow = []
    outflow = []
    with open("data/"+ filename) as csvfile:
        spamreader = csv.reader(csvfile, delimiter=",")
        for row in spamreader:
            if RepresentsInt(row[0]): 
                date += [row[1] + '/' + row[2] + '/' + row[0]]
                inflow += [re.sub('[^0-9]','',row[3])]
                outflow += [re.sub('[^0-9]','',row[4])]
        csvfile.close()
        for i in range(len(inflow)):
            if inflow[i] =='': inflow[i] = '-1'
            if outflow[i] == '': outflow[i] = '-1'
    return (date, np.array(inflow,dtype = int), np.array(outflow, dtype = int))

def load_simulated_outflow(filename = 'hydro.tsv'):
    date = []
    outflow = []
    with open("data/"+ filename) as csvfile:
        spamreader = csv.reader(csvfile, delimiter="\t")
        for row in spamreader:
            date += [row[0]]
            outflow += [row[1]]
        csvfile.close()
        for i in range(len(outflow)):
            if outflow[i] == '': outflow[i] = '-1'
    date = date[1:]
    outflow = outflow[1:]
    return (date, np.array(outflow, dtype = float))

def find(lst, values):
    return [i for i, x in enumerate(lst) if x in values]

def prep_data(inflow,outflow):
    k = 5                   #number of days to include
    a = [3,5,10,20,40,80]   #list of moving averages to include
    temp = []
    temp += inflow[i-k:i].tolist() #can remove 'tolist()' if inflow is not a numpy array
    temp += [np.mean(inflow[i-av:i]) for av in a]
    temp += outflow[i-k:i].tolist()
    temp += [np.mean(outflow[i-av:i]) for av in a]
    return temp #may need to turn this into a numpy array for mod.predict()

#def metrics(y_true, y_pred):
#    EV = ev(y_test, y_pred, multioutput = 'raw_values')
#    kge = [KGE(y_pred[:,i], y_test[:,i])[0] for i in range(y_pred.shape[-1])]
#    ns = [NS(y_pred[:,i], y_test[:,i]) for i in range(y_pred.shape[-1])]
#    rmse = np.sqrt(mse(y_test, y_pred, multioutput = 'raw_values'))
#    return np.array([EV,kge,ns,rmse])

def metrics(y_true, y_predder):
    EV = ev(y_true, y_predder, multioutput = 'raw_values')
    kge = [KGE(y_predder[:,i], y_true[:,i])[0] for i in range(y_predder.shape[-1])]
    ns = [NS(y_predder[:,i], y_true[:,i]) for i in range(y_predder.shape[-1])]
    rmse = np.sqrt(mse(y_true, y_predder, multioutput = 'raw_values'))
    return np.array([EV,kge,ns,rmse])

def clipboard_format(mat):
    line_strings = []
    for line in mat:
        line_strings.append("\t".join(line.astype(str)).replace("\n",""))
    return line_strings

#change values to run different experiment
USE_SIMULATED = False
TPOT = False

#laod data, construct labels
print("Loading data")
(date, inflow, outflow) = load_flows('flow_from_1987.csv')
outflow[outflow>2000] = 59 #max entry is 5998, which is probably an error

#limit data to era where we also have simulated data
if USE_SIMULATED:
    (date_sim, sim_out) = load_simulated_outflow('simulated_outflow.tsv')
    N = find(date, [date_sim[0], date_sim[-1]])
    date = date[N[0]:N[1]+1]
    inflow = inflow[N[0]:N[1]+1]
    outflow = outflow[N[0]:N[1]+1]

#Construct labels of next 10 days' inflow/outlfow and diff between yesterday and today
print("Making labels")
Qin = []
Qout = []
for i in range(10):
    Qin += [inflow[i:].tolist() + [0]*i]
    Qout += [outflow[i:].tolist() + [0]*i]
Q_diff = np.hstack((np.zeros((1,), dtype = int), inflow[1:] - inflow[:-1])).tolist()
y = np.array([Q_diff]+Qin+Qout).T

#make Q a series of moving averages
print("Reformatting data as a matrix")
Qs = np.vstack((inflow,outflow)).T
k = 50                   #number of days to look back
print("Each row has a memory %d days of previous flow data" %k)
a = []#[10,20,40,80]   #list of averages to record
m = np.max([k] + a)
Q_pand = []
for i in range(m,len(Qs)):
    temp = []
    temp += inflow[i-k:i].tolist()
#    temp += [np.mean(inflow[i-av:i]) for av in a]
    temp += outflow[i-k:i].tolist()
#    temp += [np.mean(outflow[i-av:i]) for av in a]
    if USE_SIMULATED: temp += [sim_out[i]]
    Q_pand += [temp]    
Q_pand = np.array(Q_pand)

#Use the last three years as test data
if TPOT: y = y[:,1]
N = np.argwhere(np.array(date, dtype = str) == '1/1/2016')[0][0]
Q_train = Q_pand[:N]
Q_test = Q_pand[N:]
y_train = y[m:N+m]
y_test = y[N+m:]

#train model
#model = RandomForestRegressor(n_estimators = 100)
#make a more convince ensemble via: https://stats.stackexchange.com/questions/139042/ensemble-of-different-kinds-of-regressors-using-scikit-learn-or-any-other-pytho
print("fitting model")
performance = []
for i in range(10):
    print(i)
    model = ExtraTreesRegressor(n_estimators = 1000, bootstrap = True, warm_start = False, n_jobs = -2)
#    model = RandomForestRegressor(n_estimators = 100, n_jobs = -2)
#    model = MultiOutputRegressor(GradientBoostingRegressor(n_estimators = 20, warm_start = False, subsample = .8), n_jobs = -2)
    model.fit(Q_train, y_train)
    
    #test model
    y_pred = model.predict(Q_test)
    performance += [metrics(y_test, y_pred)]

performance = np.array(performance)
ave_perf = np.mean(performance, axis = 0)
med_perf = np.median(performance, axis = 0)
min_perf = np.min(performance, axis = 0)
max_perf = np.max(performance, axis = 0)
std_perf = np.std(performance, axis = 0)


    
#if TPOT: model.export('tpot_pipeline.py')
#else: joblib.dump(model,'RF_res_model.pkl')

#load model with: mod = joblib.load('RF_res_model.pkl')
#today's estimated outflow: mod.predict(prep_data(inflow,outflow))[-2]