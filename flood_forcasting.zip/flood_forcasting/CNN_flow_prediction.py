#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created Summer 2018

Loads data produced by format_satellite_data.py

Defines a neural net that takes in satellite + flow data and predicts the next 10 days of flow into the reservoir

Fits model on training data and records performance on test set
@author: andrew.d.cutler@gmail.com
"""

import numpy as np
import pickle

from sklearn.metrics import explained_variance_score as ev
from sklearn.metrics import mean_squared_error as mse
from sklearn.metrics import log_loss
from new_metrics import NS, KGE

from keras.layers import Input, Dense, Dropout,Flatten,Conv1D,Reshape, Lambda, GlobalMaxPooling2D
from keras.layers import concatenate, Conv2D, CuDNNGRU, SeparableConv2D, SpatialDropout2D, MaxPooling2D
from keras.regularizers import l2
from keras.models import Model
from keras.optimizers import Adam
from keras.callbacks import ModelCheckpoint


#Define functions to save and load a model    
def save_obj(obj, name ):
    with open('data/'+ name + '.pkl', 'wb') as f:
        pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)

def load_obj(name ):
    with open('data/' + name + '.pkl', 'rb') as f:
        return pickle.load(f)
    
#takes the labels and predictions and returns the four relevent metrics as an array
def metrics(y_true, y_predder):
    if len(y_predder)==2:
        return [metrics(y_true[0],y_pred[0]),log_loss(y_true[1],y_predder[1])]
    EV = ev(y_true, y_predder, multioutput = 'raw_values')
    kge = [KGE(y_predder[:,i], y_true[:,i])[0] for i in range(y_predder.shape[-1])]
    ns = [NS(y_predder[:,i], y_true[:,i]) for i in range(y_predder.shape[-1])]
    rmse = np.sqrt(mse(y_true, y_predder, multioutput = 'raw_values'))
    return np.array([EV,kge,ns,rmse])

#block of CNN layers for the satellite data
#Data comes in with dims (time, latitude, longitude)
#corrosponds to (rgb color chanels, width, height) of traditional image data
#output dims after GloBalMaxPooling is just (filters)
#We do not expect the time dimension to interact in complex ways w/ lat/lon
#Therefore separable convs w/ an initial depthwise filter followed,
#by a pointwise filter is sufficient https://www.tensorflow.org/api_docs/python/tf/keras/layers/SeparableConv2D
#Empirically this resulted in less overfitted w/ amount of training data.
def satellite_block(Pin, drop = 0.2, reg = None):
    PC = SeparableConv2D(filters = 32, kernel_size = 3, activation = 'relu', 
                data_format='channels_first', depthwise_regularizer = reg, pointwise_regularizer = reg)(Pin)
    if drop: PC = SpatialDropout2D(rate = drop, data_format = 'channels_first')(PC)
    PC = MaxPooling2D(pool_size = (2,1), data_format = 'channels_first')(PC)
    PC = SeparableConv2D(filters = 32, kernel_size = 3, activation = 'relu', 
                data_format='channels_first',depthwise_regularizer = reg, pointwise_regularizer = reg)(PC)
    PC = SeparableConv2D(filters = 32, kernel_size = 3, activation = 'relu', strides = (2,2), 
                data_format='channels_first', depthwise_regularizer = reg, pointwise_regularizer = reg)(PC)
    if drop: PC = SpatialDropout2D(rate = drop, data_format = 'channels_first')(PC)
    PC = SeparableConv2D(filters = 16, kernel_size = 5, activation = 'relu', 
                data_format='channels_first', kernel_regularizer = reg)(PC)
    PC = GlobalMaxPooling2D(data_format = 'channels_first')(PC)
#    if drop: PC = Dropout(drop)(PC)
#    PC = MaxPooling2D(data_format = 'channels_first')(PC)
#    PC = Flatten()(PC)
    return PC

#flow and satellite data
(X_train, X_test, y_train, y_test) = load_obj('XY_traintest_50')

#Define Model
reg = l2(1e-2)
Qin = Input(shape = (X_train[0].shape[-1],))
Pin = Input(shape = X_train[1].shape[1:])
Ein = Input(shape = X_train[1].shape[1:])
Tin = Input(shape = X_train[1].shape[1:])

#transforms (time, lat, long) satellite data to a small array
PC = satellite_block(Pin, reg = reg)
EC = satellite_block(Ein, reg = reg)
TC = satellite_block(Tin, reg = reg)

#transforms historical data to a small array
x = Reshape((X_test[-1].shape[1],2))(Qin)
QC = Conv1D(filters = 16, kernel_size = 5, strides = 2, activation = 'relu',kernel_regularizer = reg)(x)
QC = Dropout(.2)(QC)
QC = Conv1D(filters = 16, kernel_size = 5, strides = 2, activation = 'relu',kernel_regularizer = reg)(QC)
QC = Conv1D(filters = 8, kernel_size = 3, strides = 1, activation = 'relu',kernel_regularizer = reg)(QC)
QC = Flatten()(QC)

#concatenate all historical and satellite arrays
#Two fully connected neural nets. Output of second layer is a prediction of inflow for next ten days
#Alternately could train ten separate nets to predict 1 day out, 2 days out, etc...
#Not advisable as this approach is a natural regularizer, harder to over-fit.
#Included predicting output from reservoir (which is a function of what operators decide)
#for this reason; harder to memorize training data w/ more labels at each time step
x = concatenate([PC,EC,TC,QC])
x = Dense(32, activation='relu', kernel_regularizer = reg)(x)
regression = Dense(y_train.shape[-1], activation = 'relu', name = 'reg_pred')(x)
model = Model(inputs = [Qin,Pin,Ein,Tin], outputs = [regression])
model.summary()

# fit model w/ a degrading step size
performance = []
cname = 'checkpoints/QC_50_1.h5py'
callback = ModelCheckpoint(filepath = cname, save_best_only = True, verbose = True)
lr = 1e-3
for i in range(5):      
    print(lr)
    opt = Adam(lr=lr)
    model.compile(optimizer = opt, loss = ['mse'])
    model.fit(X_train, y_train, 
              validation_data = (X_test, y_test), 
              epochs = 10, batch_size = 32, shuffle = True,
              callbacks = [callback])
    y_pred = model.predict(X_test)
    performance += [metrics(y_test, y_pred)]
    print(metrics(y_test,y_pred)[1,:])
    lr = lr/2
#    model = load_model(cname)


#if results bad set batch_size to 32 and reg to 1e-2 or 1e-3
